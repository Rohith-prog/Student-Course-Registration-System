
INSERT INTO students (name, email) VALUES
 ('Asha Rao','asha.rao@example.com'),
 ('Vikram Singh','vikram.singh@example.com');

INSERT INTO courses (code, title, capacity) VALUES
 ('CS101','Intro to Programming', 50),
 ('DB201','Databases with SQL', 40);

-- password is admin123 (hashed below is plain demo hash, not secure)
INSERT INTO admins (email, password_hash) VALUES
 ('admin@local', 'admin123');
