
# Student Course Registration System (CLI, Java + JDBC + MySQL)

A clean, **command-line** application that lets **admins manage courses** and **students enroll/drop** using **Java 11**, **JDBC**, and **MySQL**. Built with robust **input validation**, **exception handling**, and simple DAO architecture. Perfect for portfolio/GitHub.

## Features
- Create/list students & courses (Admin)
- Enroll and drop courses (Student)
- List a student's enrollments and course roster
- Validation for IDs, emails, and duplicates
- Graceful error handling and clear console messages
- Config-driven DB connection (`src/main/resources/db.properties`)

## Tech
- Java 11, Maven
- JDBC (MySQL 8)
- Simple DAO + Service structure
- SLF4J logging (simple backend)

## Quick Start

1) **Create DB** (MySQL 8+):
```sql
-- In MySQL
CREATE DATABASE registration_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
2) **Run schema & sample data**:
```bash
mysql -u <user> -p registration_db < sql/schema.sql
mysql -u <user> -p registration_db < sql/sample_data.sql
```

3) **Configure DB credentials**  
Copy `src/main/resources/db.properties.sample` to `src/main/resources/db.properties` and set your values.

4) **Build & Run**
```bash
mvn clean package
mvn exec:java
```
> The menu will guide you. Admin operations are under the Admin menu (default admin: `admin@local` / password: `admin123`).

## Package Structure
```
src/main/java/com/rohithk/registration/
 ├── Main.java
 ├── db/DB.java
 ├── model/{Student,Course,Enrollment}.java
 ├── dao/{StudentDao,CourseDao,EnrollmentDao}.java
 ├── dao/impl/{StudentDaoImpl,CourseDaoImpl,EnrollmentDaoImpl}.java
 ├── service/RegistrationService.java
 ├── util/InputUtil.java
 └── exceptions/AppException.java
```

## Notes
- This is intentionally compact for learning/portfolio purposes.
- Swap MySQL with another RDBMS by updating the driver & SQL dialect.
- For real systems, add tests, migrations (Flyway), and role-based auth.
