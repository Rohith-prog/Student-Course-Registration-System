
package com.rohithk.registration.dao.impl;

import com.rohithk.registration.dao.StudentDao;
import com.rohithk.registration.db.DB;
import com.rohithk.registration.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentDaoImpl implements StudentDao {
    @Override
    public Student create(Student s) {
        String sql = "INSERT INTO students(name, email) VALUES(?, ?)";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getEmail());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) s.setId(rs.getInt(1));
            }
            return s;
        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Email already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create student: " + e.getMessage());
        }
    }

    @Override
    public List<Student> list() {
        String sql = "SELECT id, name, email FROM students ORDER BY id";
        List<Student> out = new ArrayList<>();
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Student(rs.getInt("id"), rs.getString("name"), rs.getString("email")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to list students: " + e.getMessage());
        }
        return out;
    }

    @Override
    public Optional<Student> findByEmail(String email) {
        String sql = "SELECT id, name, email FROM students WHERE email=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Student(rs.getInt("id"), rs.getString("name"), rs.getString("email")));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find student: " + e.getMessage());
        }
    }

    @Override
    public Optional<Student> findById(int id) {
        String sql = "SELECT id, name, email FROM students WHERE id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Student(rs.getInt("id"), rs.getString("name"), rs.getString("email")));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find student: " + e.getMessage());
        }
    }
}
