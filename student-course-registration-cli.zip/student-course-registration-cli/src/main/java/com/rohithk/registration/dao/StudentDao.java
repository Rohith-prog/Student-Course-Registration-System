
package com.rohithk.registration.dao;

import com.rohithk.registration.model.Student;
import java.util.List;
import java.util.Optional;

public interface StudentDao {
    Student create(Student student);
    List<Student> list();
    Optional<Student> findByEmail(String email);
    Optional<Student> findById(int id);
}
