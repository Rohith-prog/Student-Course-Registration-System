
package com.rohithk.registration.dao;

import com.rohithk.registration.model.Course;
import java.util.List;
import java.util.Optional;

public interface CourseDao {
    Course create(Course course);
    List<Course> list();
    Optional<Course> findById(int id);
    Optional<Course> findByCode(String code);
    int countEnrollments(int courseId);
}
