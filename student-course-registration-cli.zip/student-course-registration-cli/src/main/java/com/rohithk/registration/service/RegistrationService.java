
package com.rohithk.registration.service;

import com.rohithk.registration.dao.CourseDao;
import com.rohithk.registration.dao.EnrollmentDao;
import com.rohithk.registration.dao.StudentDao;
import com.rohithk.registration.dao.impl.CourseDaoImpl;
import com.rohithk.registration.dao.impl.EnrollmentDaoImpl;
import com.rohithk.registration.dao.impl.StudentDaoImpl;
import com.rohithk.registration.model.Course;
import com.rohithk.registration.model.Enrollment;
import com.rohithk.registration.model.Student;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class RegistrationService {
    private final StudentDao studentDao = new StudentDaoImpl();
    private final CourseDao courseDao = new CourseDaoImpl();
    private final EnrollmentDao enrollmentDao = new EnrollmentDaoImpl();

    // Auth (simplified demo)
    public boolean adminLogin(String email, String password) {
        // Demo-only: select from admins table where email/password matches (plain text for demo)
        // In production, use BCrypt hashes and salted passwords.
        try (var con = com.rohithk.registration.db.DB.getConnection();
             var ps = con.prepareStatement("SELECT 1 FROM admins WHERE email=? AND password_hash=?")) {
            ps.setString(1, email);
            ps.setString(2, password);
            try (var rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            return false;
        }
    }

    public String createStudent(String name, String email) {
        if (name == null || name.isBlank()) return "Name is required.";
        if (email == null || !email.matches("^[\\w._%+-]+@[\\w.-]+\\.[A-Za-z]{2,}$")) return "Invalid email.";
        Student s = studentDao.create(new Student(name.trim(), email.trim().toLowerCase()));
        return "Created " + s;
    }

    public List<String> listStudents() {
        return studentDao.list().stream().map(Student::toString).collect(Collectors.toList());
    }

    public String createCourse(String code, String title, int capacity) {
        if (capacity <= 0) return "Capacity must be positive.";
        Course c = courseDao.create(new Course(code.trim().toUpperCase(), title.trim(), capacity));
        return "Created " + c;
    }

    public List<String> listCourses() {
        return courseDao.list().stream().map(Course::toString).collect(Collectors.toList());
    }

    public String enroll(int studentId, int courseId) {
        Optional<Student> s = studentDao.findById(studentId);
        if (s.isEmpty()) return "Student not found.";
        Optional<Course> c = courseDao.findById(courseId);
        if (c.isEmpty()) return "Course not found.";
        if (enrollmentDao.exists(studentId, courseId)) return "Student already enrolled.";
        int current = courseDao.countEnrollments(courseId);
        if (current >= c.get().getCapacity()) return "Course is full.";
        Enrollment e = enrollmentDao.enroll(new Enrollment(studentId, courseId));
        return "Enrolled " + s.get().getName() + " to " + c.get().getCode() + " (enrollmentId=" + e.getId() + ")";
    }

    public String drop(int studentId, int courseId) {
        boolean ok = enrollmentDao.drop(studentId, courseId);
        return ok ? "Dropped enrollment." : "Enrollment not found.";
    }

    public List<String> getStudentEnrollments(int studentId) {
        return enrollmentDao.listByStudent(studentId).stream()
                .map(e -> String.format("Enrollment{id=%d, studentId=%d, courseId=%d}", e.getId(), e.getStudentId(), e.getCourseId()))
                .collect(Collectors.toList());
    }

    public List<String> getCourseRoster(int courseId) {
        return enrollmentDao.roster(courseId);
    }
}
